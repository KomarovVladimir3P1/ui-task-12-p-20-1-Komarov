﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace _12.Core_Data
{
    public class DataAppLoad :INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;
        private void NotifyPropertyChanged(string name) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        Visibility visibility;

        public Visibility Visibility
        {
            get { return visibility; }

            set
            {
                visibility = value;
                NotifyPropertyChanged("Visibility");
            }
        }
        public DataAppLoad() =>
            Visibility = Visibility.Collapsed;

        public void LoadContent()
        {
            Visibility = Visibility.Visible;

            var v = new Thread(() =>
            {
                Thread.Sleep(2500);
                Visibility = Visibility.Collapsed;
            });

            v.Start();
        }
    }
}
